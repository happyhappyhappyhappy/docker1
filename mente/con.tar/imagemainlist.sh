#!/bin/bash
docker image ls | cut -c 1-55,66-80,95- 